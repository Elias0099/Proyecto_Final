package com.exam.exam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
